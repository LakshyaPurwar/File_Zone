// const { format } = require("path/posix");

$("input").change((event)=>{
    $("span").text(event.target.value.slice(12));
    $("label").html('<svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="96" height="96" viewBox="0 0 172 172"style=" fill:#000000;"><g fill="none" fill-rule="nonzero" stroke="none" stroke-width="1" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" style="mix-blend-mode: normal"><path d="M0,172v-172h172v172z" fill="none"></path><g><path d="M143.33333,161.25h-114.66667v-150.5h78.83333l35.83333,35.83333z" fill="#ffffff"></path><path d="M137.95833,50.16667h-34.04167v-34.04167z" fill="#fbe9e7"></path><path d="M57.33333,139.75c-1.43333,0 -2.50833,-0.35833 -3.58333,-0.71667c-3.94167,-2.15 -4.3,-5.375 -3.58333,-7.88333c1.43333,-4.3 9.31667,-9.675 19.70833,-14.33333v0c4.65833,-8.6 8.24167,-17.55833 10.39167,-25.08333c-3.58333,-6.80833 -5.375,-13.25833 -5.375,-17.91667c0,-2.50833 0.71667,-4.65833 1.79167,-6.45c1.43333,-1.79167 3.58333,-2.86667 6.45,-2.86667c3.225,0 5.73333,1.79167 6.80833,5.01667c1.79167,4.3 0.71667,12.18333 -1.79167,21.14167c3.58333,6.09167 7.88333,11.825 12.54167,16.125c6.80833,-1.43333 12.9,-2.15 16.84167,-1.43333c6.80833,1.075 7.88333,5.73333 7.88333,7.525c0,7.525 -7.88333,7.525 -10.75,7.525c-5.375,0 -10.75,-2.15 -15.40833,-6.09167v0c-8.6,2.15 -17.2,5.01667 -24.00833,8.24167c-3.58333,6.09167 -7.16667,11.10833 -10.39167,13.975c-3.225,2.50833 -5.73333,3.225 -7.525,3.225zM61.63333,129.35833c-1.79167,1.075 -3.225,2.15 -3.94167,3.225c0.71667,-0.35833 2.15,-1.075 3.94167,-3.225zM110.36667,112.51667c1.43333,0.35833 2.86667,0.71667 4.3,0.71667c2.15,0 3.225,-0.35833 3.58333,-0.35833v0c-0.35833,-0.35833 -2.86667,-1.075 -7.88333,-0.35833zM85.28333,99.61667c-1.43333,4.3 -3.58333,8.95833 -5.375,13.25833c4.3,-1.43333 8.6,-2.86667 12.9,-3.94167c-2.86667,-2.86667 -5.375,-6.09167 -7.525,-9.31667zM83.13333,71.66667c-0.35833,0 -0.35833,0 -0.35833,0c-0.35833,0.35833 -0.71667,2.86667 0.71667,8.24167c0.35833,-4.3 0.35833,-7.525 -0.35833,-8.24167z" fill="#ffffff"></path></g></g></svg>');
    $(document).scrollTop(180);
});


$("#ocr").click(()=>{
    $("form").attr("action","/OCR");
    // console.log( $("form").attr("action"));
    $("input").attr("name","avatar");
    // console.log($("input").attr("name"));
    $("#submitOCR").trigger("click");

});

$("#wordtopdf").click(()=>{
    $("form").attr("action","/WORDTOPDF");
    // console.log( $("form").attr("action"));
    $("input").attr("name","avatar");
    // console.log($("input").attr("name"));
    $("#submitOCR").trigger("click");//there might be  change here

});


$("#pdftoword").click(()=>{
    $("form").attr("action","/PDFTOWORD");
    // console.log( $("form").attr("action"));
    $("input").attr("name","avatar");
    // console.log($("input").attr("name"));
    $("#submitOCR").trigger("click");//there might be  change here

});

$(window).click((event)=>{
    console.log(event.pageX);
    console.log(event.pageY);
    
});



// $(".reload").click(()=>{
//     // 
//     $("#reset").click();
// });


{/* <form action="/ocr" method="POST" enctype="multipart/form-data">
<input type="file" name="avatar">
<button type="submit">Convert</button>
</form> */}